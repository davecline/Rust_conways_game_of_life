import * as wasm from "wasm-game-of-life";

//const name = prompt("What's your name");
//wasm.greet(name);

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
const pre = document.getElementById("game-of-life-canvas");
const universe = wasm.Universe.new(950);

// const renderLoop = () => {
//     pre.textContent = universe.render();
//     universe.tick();
//     requestAnimationFrame(renderLoop);
//   };

// requestAnimationFrame(renderLoop);

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

var stop = false;
var frameCount = 0;
var $results = document.getElementById("game-of-life-canvas"); //$("#results");
var fps, fpsInterval, startTime, now, then, elapsed;

// initialize the timer variables and start the animation
function startAnimating(fps) {
    fpsInterval = 1000 / fps;
    then = Date.now();
    startTime = then;
    animate();
}

// the animation loop calculates time elapsed since the last loop
// and only draws if your specified fps interval is achieved

function animate() {

    // request another frame
    requestAnimationFrame(animate);

    // calc elapsed time since last loop
    now = Date.now();
    elapsed = now - then;

    // if enough time has elapsed, draw the next frame
    if (elapsed > fpsInterval) {

        // Get ready for next frame by setting then=now, but also adjust for your
        // specified fpsInterval not being a multiple of RAF's interval (16.7ms)
        then = now - (elapsed % fpsInterval);

        // Put your drawing code here
        pre.textContent = universe.render();
        let boost = new Date().getMilliseconds();
        universe.tick(boost % 621 === 0 ? 1 : 0);

        // if (boost % 115 ===0){
        //     document.getElementsByTagName("body")[0].style.color = 'red';
        // }
        // if (boost % 129 ===0){
        //     document.getElementsByTagName("body")[0].style.color = 'green';
        // }
        // if (boost % 151 ===0){
        //     document.getElementsByTagName("body")[0].style.color = 'black';
        // }
        // if (boost % 111 ===0){
        //     document.getElementsByTagName("body")[0].style.color = 'blue';
        // }
    }
}

startAnimating(20);